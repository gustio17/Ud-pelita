import React from "react";

export default function HomePage() {
  return (
    <div className="bg-[#fefcf9] text-[#3e2c1e]">
      {/* Header */}
      <header className="bg-[#7a5230] text-white px-6 py-4 flex justify-between items-center">
        <h1 className="text-xl font-bold">UD Pelita Mandiri</h1>
        <nav className="space-x-4">
          <a href="#beranda" className="hover:underline">Beranda</a>
          <a href="#produk" className="hover:underline">Produk</a>
          <a href="#kontak" className="hover:underline">Kontak</a>
        </nav>
      </header>

      {/* Hero */}
      <section id="beranda" className="bg-[#e7dbc9] text-center py-16 px-4">
        <h2 className="text-3xl font-semibold mb-4">Selamat Datang di UD Pelita Mandiri</h2>
        <p className="mb-6">Spesialis kayu dan kusen pintu & jendela berkualitas</p>
        <a
          href="https://wa.me/6281265189991"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-[#25d366] text-white px-6 py-2 rounded-lg shadow hover:bg-green-600"
        >
          Hubungi via WhatsApp
        </a>
      </section>

      {/* Produk */}
      <section id="produk" className="py-12 px-4">
        <h3 className="text-2xl font-bold mb-6 text-center">Produk Kami</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {["SK", "Mahoni", "Meranti"].map((jenis) => (
            <div key={jenis} className="bg-white rounded-xl shadow p-4 text-center">
              <img
                src={`https://via.placeholder.com/300x200?text=Kusen+${jenis}`}
                alt={`Kusen ${jenis}`}
                className="rounded mb-2 mx-auto"
              />
              <h4 className="font-semibold text-lg">Kusen Kayu {jenis}</h4>
              <p className="text-sm text-gray-600">Kualitas tinggi, cocok untuk berbagai kebutuhan bangunan.</p>
            </div>
          ))}
        </div>
      </section>

      {/* Kontak & Lokasi */}
      <section id="kontak" className="py-12 px-4 bg-[#f5e9d6]">
        <h3 className="text-2xl font-bold mb-4 text-center">Kontak & Lokasi</h3>
        <div className="text-center mb-4">
          <p>Alamat: Jl. Linggis, Cengkeh Turi</p>
          <p>WhatsApp: <a className="text-green-700 font-semibold" href="https://wa.me/6281265189991" target="_blank">0812-6518-9991</a></p>
        </div>
        <div className="max-w-3xl mx-auto">
          <iframe
            src="https://www.google.com/maps?q=Jl.+Linggis,+Cengkeh+Turi&output=embed"
            className="w-full h-72 rounded-lg border"
            allowFullScreen=""
            loading="lazy"
          ></iframe>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#7a5230] text-white text-center py-4">
        &copy; 2025 UD Pelita Mandiri. Semua hak dilindungi.
      </footer>
    </div>
  );
}